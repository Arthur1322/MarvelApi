import { useEffect, useState } from 'react';
import Card from '../../Components/Card';
import styles from './movies.module.css';
import Footer from '../../Components/Footer';

function Movies() {
    const [filmes, setFilmes] = useState([]);

    useEffect(() => {
        const buscarFilmes = async () => {
            const response = await fetch('./filmes_marvel.json')
            const data = await response.json()
            setFilmes(data.filmes_marvel)
        }
        buscarFilmes()
    }, []);

    return (
        <>
        <div className={styles.Movies}>
            {filmes.map((filme, index) => (
                <Card key={index} img={filme.img} nome={filme.titulo}  />
            ))}
           
        </div>
         <Footer />
        </>
    );
}

export default Movies;
