import Footer from '../../Components/Footer';
import './home.module.css';

function Home(){
    return(
        <>
            <Footer/>
        </> 

    )
    
}

export default Home