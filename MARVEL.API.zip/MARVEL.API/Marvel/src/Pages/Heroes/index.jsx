import { useEffect, useState } from 'react';
import Card from '../../Components/Card';
import styles from './heroes.module.css';
import Footer from '../../Components/Footer';

function Heroes() {
    const [heroes, setHeroes] = useState([]);

    useEffect(() => {
        const buscarHerois = async () => {
            const response = await fetch('./herois_Marvel.json')
            const data = await response.json()
            setHeroes(data.herois_marvel)
        }
        buscarHerois()
    }, []);

    return (
        <>
        <div className={styles.Heroes}>
            {
                heroes.map((hero, index) => (
                    <Card key={index} img={hero.img} nome={hero.nome} atores={hero.identidade_secreta}  />
            ))}
        </div>
        <Footer />
        </>
    );
}

export default Heroes;
