
import styles from './Card.module.css';

function Card({ nome, atores, img }) {
  return (
    <div className={styles.Card} > 
      <img src={img} alt="" className={styles.img} />
      <h1>{nome}</h1>
      <p>{atores}</p>
    </div>
  );
}

export default Card;
