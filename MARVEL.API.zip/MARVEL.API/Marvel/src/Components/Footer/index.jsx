import styles from './Footer.module.css';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className={styles.Footer}>
      <nav>
        <Link to='/' className={styles.home}>HOME</Link>
        <Link to='/movies' className={styles.movie}>MOVIE</Link>
        <Link to='/heroes' className={styles.heroes}>HEROES</Link>
      </nav>
    </footer>
  );
}

export default Footer;
