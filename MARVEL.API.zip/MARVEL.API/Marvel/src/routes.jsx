import { BrowserRouter, Routes, Route } from  'react-router-dom'

import Heroes from './Pages/Heroes'
import Movies from './Pages/Movies'
import Home from './Pages/Home'

function AppRoutes(){
    return(
        <BrowserRouter>

            <Routes>
                <Route path='/' element={ <Home />}></Route>
                <Route path='/Movies' element={ <Movies />}></Route>
                <Route path='/Heroes' element={ <Heroes />}></Route>
            </Routes>

        </BrowserRouter>
    )
}

export default AppRoutes